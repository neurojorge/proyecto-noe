#include <iostream>
#include <windows.h>
#include <string>
#include <limits>
#include <vector>

#include "Venado.h"
#include "Antilope.h"
#include "Oso.h"

vector<Oso> Bear;
vector<Antilope> Anti;
vector<Venado> Deer;

int flago=0, flagv=0, flaga=0;

using namespace std;

void comparar(){

}

void muestra(){
    int t= flaga+ flagv + flago+ 5;
    cout<< "El teexto se mostrara por "<<t<< "seg."<<endl;
    if(flago != 0){
    for(int i=0; i<flago; i++){
        cout<< Bear[i]<<endl;
        Bear[i].mostrarEstado();
    }
    }
    if(flagv != 0){
    for(int i=0; i<flagv; i++){
    cout<< Deer[i]<<endl;
    Deer[i].mostrarEstado();
    }
    }
    if(flaga != 0){
    for(int i=0; i<flaga; i++){
    cout<< Anti[i]<<endl;
    Anti[i].mostrarEstado();
    }
    }
Sleep(t*1000);
}

void baja(){
    int Y;
    system("cls");
    cout<< "Que animal quieres dar de baja:"<<endl;
    cout<< "1. Oso"<<endl;
    cout<< "2. Venado"<<endl;
    cout<< "3. Antilope"<< endl;
    cout<< "4. Salir"<< endl;
    try{
    cin>>Y;
     if (cin.fail()) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');

               throw runtime_error("Entrada no vlida. Debes ingresar un numero.");

            }
            }
            catch (const exception &e) {
                cout << e.what();
               Sleep(3000);
            }
            system("cls");
    switch(Y){
case 1:{

    int B;

    cout<< "Cual oso quieres dar por muero:"<<endl;
    for(int i=0; i<flago; i++){
        cout<<i+1 << " "<<Bear[i].nombre<<endl;
    }
    cin>>B;

    B=B-1;
    cout<<Bear[B].nombre<<endl;
    Bear[B].morir();
    Bear[B].mostrarEstado();
    Sleep(2000);
    break;
}
case 2:{
    int D;

    cout<< "Cual venado quieres dar por muero:"<<endl;
    for(int i=0; i<flagv; i++){
        cout<<i+1 << " "<<Deer[i].nombre<<endl;
    }
    cin>>D;
    D=D-1;
    cout<<Deer[D].nombre<<endl;
    Deer[D].morir();
    Deer[D].mostrarEstado();
    Sleep(2000);
    break;
}
case 3:{

    int A;
    cout<< "Cual antilope quieres dar por muero:"<<endl;
    for(int i=0; i<flaga; i++){
        cout<<i+1 << " "<<Anti[i].nombre<<endl;
    }
    cin>>A;
    A=A-1;
    cout<<Anti[A].nombre<<endl;
    Anti[A].morir();
    Anti[A].mostrarEstado();
    Sleep(2000);
    break;
}
case 4:
    break;

default:
    cout<< "Vuelve a intentarlo"<<endl;
    break;
    }
}

void ingreso(){
    int Y=0;
    cout<< "Que animal quieres agregar:"<<endl;
    cout<< "1. Oso"<<endl;
    cout<< "2. Venado"<<endl;
    cout<< "3. Antilope"<< endl;
    cout<< "4. Salir"<< endl;
    try{
    cin>>Y;
     if (cin.fail()) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');

               throw runtime_error("Entrada no vlida. Debes ingresar un numero.");

            }
            }
            catch (const exception &e) {
                cout << e.what();
               Sleep(3000);
            }
            system("cls");
    switch(Y){
case 1:{
    flago++;
    Oso o;
    cin>>o;
    Bear.push_back(o);
    cout << "Oso agregado correctamente." << endl;
    break;
}
case 2:{
    flagv++;
    Venado v;
    cin >> v;
    Deer.push_back(v);
    cout << "Venado agregado correctamente." << endl;
    break;
}
case 3:{
    flaga++;
    Antilope a;
    cin>>a;
    Anti.push_back(a);
    cout << "Antilope agregado correctamente." << endl;
    break;
}
case 4:
    break;

default:
    cout<< "Vuelve a intentarlo"<<endl;
    break;

    }
    system("cls");
}



int main()
{

    int Fin=0;// este da el final del codigo
    int X; //este manipula el menu principal
    //portada

    cout << "=============================================================\n";
    cout << "=============================================================\n";
    cout << "  _  __   ___   _  __ ___  ____  ___ \n";
    cout << " | |/ /  / _ \\ | |/ // _ \\|  _ \\|_ _|\n";
    cout << " | ' /  | | | || ' /| | | | |_) || | \n";
    cout << " | . \\  | |_| || . \\| |_| |  _ < | | \n";
    cout << " |_|\\_\\  \\___/ |_|\\_\\\\___/|_| \\_\\___|\n";
    cout << "                                      \n";
    cout << "=============================================================\n";
    cout << "=============================================================\n\n";

    std::cout << "Bienvenido guardian del bosque.\n";
    std::cout << "Protejamos juntos la vida que florece en Kokiri\n";
    Sleep(4000);

    do{
            system("cls");
            cout << "Selecciona la opcion (ingresar el numero de la eleccion)"<<endl;
            cout << "1.-Ingresar nuevo animal"<<endl;
            cout << "2.-Dar de baja un animal (borrar del sistema o darlo por muerto)"<<endl;
            cout << "3.-Mostrar animales"<<endl;
            cout << "4.-Comparar los animales (de la misma especie)"<<endl;
            cout << "5.-Salir"<<endl;
            try{
            cin>>X;
            if (cin.fail()) {
                cin.clear(); // Limpia el estado de error
                cin.ignore(numeric_limits<streamsize>::max(), '\n');

               throw runtime_error("Entrada no vlida. Debes ingresar un numero.");

            }
            }
            catch (const exception &e) {
                cout << e.what();
               Sleep(3000);
            }
            system("cls");
            switch(X){
            case 1:

                ingreso();
                    break;

            case 2:

                baja();
                break;

            case 3:

                muestra();
                break;

            case 4:

                comparar();
                break;

            case 5:
                Fin=1;
                break;

            default:
                cout<< "El numero debe estar entre los parametros"<<endl;
                break;
            }


    }
    while(Fin==0);
    cout << "Hello world!" << endl;
    return 0;
}
