#include "Especie.h"

Especie::Especie(){

}
Especie::Especie(int v, float tamanol, string alimentacionl, string generol, float pesol): Vida(v)
{
    //ctor
    tamano=tamanol;
    alimentacion=alimentacionl;
    genero=generol;
    peso=pesol;
}

void Especie::morir() {
    cout << "La especie ha muerto" << endl;
}

void Especie::mostrarEstado() const {
        cout << "Estado general de la especie" << endl;
}

Especie::~Especie()
{
    //dtor
}
