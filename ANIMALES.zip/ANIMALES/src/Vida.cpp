#include "Vida.h"

Vida::Vida()
{
    //ctor

}

Vida::Vida(int edadmaxl)
{
    //ctor
    edadmax=edadmaxl;
}

Vida::~Vida()
{
    //dtor
}
