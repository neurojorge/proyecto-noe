#include "Oso.h"

Oso::Oso(){

}

Oso::Oso(string nombrel, int v, float tamano, string alimentacion, string genero, float peso): Especie( v, tamano, alimentacion, genero, peso)
{
    //ctor
    nombre= nombrel;
    estado=true;
}

ostream& operator << (ostream &out, const Oso &bear){
    out<< "El nombre del oso es "<< bear.nombre <<endl;
    out<< "Su tamano es "<<bear.tamano<<", su edad es "<<bear.edadmax<< " y su peso es de "<<bear.peso<<endl;
    out<< "El genero del oso es "<< bear.genero << "Y se alimenta de "<< bear.alimentacion <<endl;
    return out;
}

istream& operator>>(istream &in, Oso &bear) {
    int OG;
cout << "Dame un nombre para el oso: " << endl;
in >> bear.nombre;

do{
try {
cout << "Dame edad: " << endl;
in >> bear.edadmax;
OG=0;
if (cin.fail()) {
cin.clear();
cin.ignore(1000, '\n');
throw invalid_argument("Entrada no valida. Debes ingresar un numero");
}
OG=0;
if (bear.edadmax > 20) {
throw invalid_argument("La edad de un oso no puede ser mayor a 20 anos");
}
if (bear.edadmax < 0) {
throw invalid_argument("La edad debe ser positiva");
}
}
catch (const exception& e) {
    OG=1;
cout << "Error: " << e.what() << endl;
}
}
while(OG!=0);

do{
try {
cout << "Dame el tamano en centimetros: " << endl;
in >> bear.tamano;
if (cin.fail()) {
cin.clear();
cin.ignore(1000, '\n');
throw invalid_argument("Entrada no valida. Debes ingresar un numero");
}
OG=0;
if (bear.tamano > 210) {
throw invalid_argument("Los osos no miden mas de 210 cm");
}
if (bear.tamano < 45) {
throw invalid_argument("Los osos no miden menos de 45 cm");
}
}
catch (const exception& e) {
    OG=1;
cout << "Error: " << e.what() << endl;
}
}
while(OG!=0);

do{
try {
cout << "Que tipo de alimento come (carne o vegetales)?: " << endl;
in >> bear.alimentacion;
if (cin.fail()) {
cin.clear();
cin.ignore(1000, '\n');
throw invalid_argument("Entrada no valida. Debes ingresar el alimento correcto");
}
OG=0;
if (bear.alimentacion != "carne" && bear.alimentacion != "vegetales") {
throw invalid_argument("Vuelve a escribir 'carne' o 'vegetales'");
}
}
catch (const exception& e) {
    OG=1;
cout << "Error: " << e.what() << endl;
}
}
while(OG!=0);

do{
try {
cout << "De que genero es (macho o hembra)?: " << endl;
in >> bear.genero;
if (cin.fail()) {
cin.clear();
cin.ignore(1000, '\n');
throw invalid_argument("Entrada no valida. Debes ingresar el genero correcto");
}
OG=0;
if (bear.genero != "macho" && bear.genero != "hembra") {
throw invalid_argument("Vuelve a escribir 'macho' o 'hembra'");
}
}
catch (const exception& e) {
    OG=1;
cout<< "Error: " << e.what() << endl;
}
}
while(OG!=0);
do{
try {
cout << "Dame el peso del oso (kg): " << endl;
in >> bear.peso;
if (cin.fail()) {
cin.clear();
cin.ignore(1000, '\n');
throw invalid_argument("Entrada no valida. Debes ingresar el genero correcto");
}
OG=0;
if (bear.peso > 180) {
throw invalid_argument("Es muy pesado para un oso");
}
if (bear.peso < 40) {
throw invalid_argument("Es muy delgado para un oso");
}
}
catch (const exception& e) {
    OG=0;
cout << "Error: " << e.what() << endl;
}
}
while(OG!=0);
return in;
}


Oso Oso::operator+(Oso &bear)  {
    Oso tmp;
    tmp.edadmax= edadmax +bear.edadmax;
    tmp.tamano= tamano+ bear.tamano;
    tmp.peso= peso + bear.peso;
    return tmp;
}
Oso Oso::operator-(Oso &bear)  {
    Oso tmp;
    tmp.edadmax= edadmax -bear.edadmax;
    tmp.tamano= tamano - bear.tamano;
    tmp.peso= peso - bear.peso;
    return tmp;
}
Oso Oso::operator*(Oso &bear)  {
    Oso tmp;
    tmp.edadmax= edadmax*bear.edadmax;
    tmp.tamano= tamano* bear.tamano;
    tmp.peso= peso * bear.peso;
    return tmp;
}
Oso Oso::operator/(Oso &bear)  {
    Oso tmp;
    tmp.edadmax= edadmax/bear.edadmax;
    tmp.tamano= tamano / bear.tamano;
    tmp.peso= peso /  bear.peso;
    return tmp;
}
Oso Oso::operator<(Oso &bear){
    Oso tmp;
    tmp.edadmax= edadmax<bear.edadmax;
    if(tmp.edadmax==1){
        cout<<tmp.nombre<< "Es mas viejo que el otro oso"<<endl;
    }
    else{
        cout<<tmp.nombre<< "Es mas viejo que el otro oso"<<endl;
    }
    tmp.tamano= tamano < bear.tamano;
    tmp.peso= peso <  bear.peso;
    return tmp;

}
Oso Oso::operator>(Oso &bear){
    Oso tmp;
    tmp.edadmax= edadmax>bear.edadmax;
    tmp.tamano= tamano > bear.tamano;
    tmp.peso= peso >  bear.peso;
    return tmp;
}



Oso::~Oso()
{
    //dtor
}
